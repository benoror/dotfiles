# Set path to perl scripts.
export PATH="${PATH}:/usr/bin/perlbin/site:/usr/bin/perlbin/vendor:/usr/bin/perlbin/core"
